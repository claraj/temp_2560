var Student = sequelize.define('Student', {
 name: {
     type: DataTypes.STRING, 
 },  star ID: {
     type: DataTypes.STRING,
 }, present: {
     type: DataTypes.BOOLEAN
 }   
})