<template>
  <div id="app">
    <NewStudentForm v-on:student-added="newStudentAdded"></NewStudentForm>
    <StudentTable 
    v-bind:students="students" 
    v-on:student-present="studentArrivedOrLeft"
    v-on:delete-student="studentDeleted">  
    </StudentTable>
    <StudentMessage v-bind:message="message" v-bind:name="name"></StudentMessage>
    <!-- <msg="Welcome to Your Vue.js App"> -->
  </div>
</template>

<script>
import NewStudentForm from './components/NewStudentForm.vue'
import StudentTable from './components/StudentTable.vue'
import StudentMessage from './components/StudentMessage.vue'

export default {
  name: 'App',
data() {
  return {
    students: [],
    message: '',
    name: ''
  }
},
  components: {
    NewStudentForm,
    StudentTable,
    StudentMessage
  },
  mounted() {
    this.updateStudents()
  },
  methods: {
    newStudentAdded(student) {
      this.$student_ai.addStudent(student).then( student => {
        this.updateStudents()
    })

    },
    studentArrivedOrLeft(student) {
      
    },
    studentDeleted(student) {
    },
  updateStudents() {
    this.$student_api.getAllStudents().then( students => {
      this.students = students

  
    })
  },
 
  }
 }

</script>

<style>

</style>
