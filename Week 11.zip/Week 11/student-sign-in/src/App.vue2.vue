<template>
  <div id="app">
    <NewStudentForm></NewStudentForm>
    <StudentTable></StudentTable>
    <StudentMessage></StudentMessage>
    <!-- < msg="Welcome to Your Vue.js App"/> -->
  </div>
</template>

<script>
import NewStudentForm from './components/NewStudentForm.vue'
import StudentTable from './components/StudentTable.vue'
import StudentMessage from './components/StudentMessage.vue'

export default {
  name: 'App',
  components: {
    NewStudentForm,
    StudentTable,
    StudentMessage
  }
}
</script>

<style>

</style>
