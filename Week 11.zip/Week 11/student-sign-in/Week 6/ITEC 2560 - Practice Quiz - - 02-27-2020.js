<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
</head>
<body>

    <!-- Write your HTML content here -->

<script>

    // Write your script here


let arr = ('oak', 'palm', 'birch'){
arr.forEach[ tree => console.logtree)}
</script>

</body>
</html>
© 2020 GitHub, Inc.