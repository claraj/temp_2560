
<DOCTYPE html>
   
    <html>
    <head>
    <title>Hello Fetch - Where's the ISS</title>
    <!-- async = load the script in parallelwith the HTML
    defer = wait until the HTML has finished loading bedfore runniong the script -->
    <script async defer src="ITEC2560-Assignment6-MapMarker">
    // let url = 'ITEC2560-Assignment6b-fetch-iss.js',
    let map = L.map('iss-map').setView([0, 0], 1)
L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery &copy; <a href="https://www.mapbox.com/">Mapbox</a>',
id: 'mapbox.streets',
accessToken: 'pk.eyJ1IjoibWVsdmluY29sZW1hbiIsImEiOiJjazZ2Y29ycm0wMGlxM2Vsa2IycWQxeGNiIn0.CphC2p5y36bpBbWBiyHrpw'
}).addTo(map)
let issLat = document.querySelector('#iss-lat')
let issLong = document.querySelector('#iss-long')

//make request to API which returns a promise
function iss() {
fetch(url)
    .then(res => res.json() ) //decoder binary response into js object
    .then(issData =>{
        console.log(issData)
        let lat = issData.latitude
        let long = issData.longitude
        issLat.innerHTML =lat
        issLong.innerHTML = long

        // let issMarker = L.marker([lat, long]).addTo(map) // Create the Marker
    }

        if (issMarker){
            issMarker=L.Marker([lat, long]).set  // Create the Marker
        }else(
            issMarker.setLatLng([lat, long]) Already Exists - Move to New Location
        )
        }
    })
    .catch( err => {
        console.log(err)
    })
    </head>
    <body>
    
    <h1>Where is the International Space Station?</h1>
    <div>
        <p>ISS Latitude: <span id="iss-lat"></span></p>
        <p>ISS Longitude: <span id="iss-long"></span</p>
    </script>
    </head>
    </html>
    </DOCTYPE>