// Copy link from slides
let url = 'https://api.wheretheiss.at/v1/satellites/25544'

let issLat = document.querySelector('#iss-lat')
let issLong = document.querySelector('#iss-long')

//make request to API which returns a promise
fetch(url)
    .then(res => res.json() ) //decoder binary response into js object
    .then(issData =>{
        console.log(issData)
        let lat = issData.latitude
        let long = issData.longitude
        issLat.innerHTML =lat
        issLong.innerHTML = long
    })
    .catch( err => {
        console.log(err)
    })