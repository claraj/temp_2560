var issMarker // Leaflet Marker
var update = 10000

let map = L.map('iss-map').setView([0, 0], 1)
L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery &copy; <a href="https://www.mapbox.com/">Mapbox</a>',
id: 'mapbox.streets',
accessToken: 'pk.eyJ1IjoibWVsdmluY29sZW1hbiIsImEiOiJjazZ2Y29ycm0wMGlxM2Vsa2IycWQxeGNiIn0.CphC2p5y36bpBbWBiyHrpw'
}).addTo(map)
// Copy link from slides
let url = 'https://api.wheretheiss.at/v1/satellites/25544'

let issLat = document.querySelector('#iss-lat')
let issLong = document.querySelector('#iss-long')

iss()
//make request to API which returns a promise
function iss() {
fetch(url)
    .then(res => res.json() ) //decoder binary response into js object
    .then(issData =>{
        console.log(issData)
        let lat = issData.latitude
        let long = issData.longitude
        issLat.innerHTML =lat
        issLong.innerHTML = long

        // let issMarker = L.marker([lat, long]).addTo(map) // Create the Marker


        if (!issMarker){
            issMarker=L.marker([lat, long]).addTo(map)  // Create the Marker
        }else{

            issMarker.setLatLng([lat, long]) // Already Exists - Move to New Location
        }
    })
    .catch( err => {
        console.log(err)
    })}