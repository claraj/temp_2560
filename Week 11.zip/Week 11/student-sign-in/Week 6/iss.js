// Copy link from slides
fetch(url) = 'https://api.wheretheiss.at/v1/satellites/25544'

let isslat = document.querySelector(#iss-lat)
let isslong = document.queryySelector(#iss-long)

//make request to API which returns a promise
fetch(url)
.then((response => {
    return response.json() //decoder binary response into js object
    console.log(issData)
    let lat = issData.latitude
    let long = issData.longitude
    issLat.innerHTML =lat
    issLong.innerHTML = longitude
})
.catch( err => {
    console.log(err)
})
    
    </issData></issData>
}))



//Slide #28
#iss-map {
    height: 400px;
    width: 500px;
}