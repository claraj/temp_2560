<template>
    <div>
    <transition name="fade">
            <!-- TO DO welcome or goodbye message -->
            <div class="alert alert-success">{{message}} {{name}}</div>
    </transition>  
        
    </div>

</template>


<script>

export default {
    name: 'StudentMessage',
    data() {
        return {
            seeMessage: false
        }
},
props: {
    message: String,
    name: String
},
watch: {
    message() {
        this.seeMessage = true
        setTimeout ( () => {
    }, 3000)
  }
}

}
</script>

<style>
.fade-enter-active, .fade-leave-active {
    transition: opacity .5s;
}

.fade-enter, .fade-leave-to {
    opacity: 0;
}

#student-table {
    max-height: 500px;
    overflow: scroll;
}
</style>